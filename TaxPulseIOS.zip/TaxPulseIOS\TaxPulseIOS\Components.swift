import SwiftUI

struct AppCard<Content: View>: View {
    var padding: CGFloat = 18
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            content
        }
        .padding(padding)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.slateBorder, lineWidth: 1)
        )
    }
}

struct ResultRow: View {
    var title: String
    var value: String
    var valueColor: Color = .slateTextDark
    var isBold = false

    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title)
                .font(.system(size: 12, weight: isBold ? .bold : .regular))
                .foregroundStyle(Color.slateTextLight)
            Spacer(minLength: 12)
            Text(value)
                .font(.system(size: 12, weight: isBold ? .black : .bold))
                .foregroundStyle(valueColor)
                .multilineTextAlignment(.trailing)
        }
    }
}

struct PillButton: View {
    var title: String
    var systemImage: String
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Label(title, systemImage: systemImage)
                .font(.system(size: 13, weight: .bold))
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(Color.blueAccent.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 9, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 9, style: .continuous)
                        .stroke(Color.blueAccent.opacity(0.25), lineWidth: 1)
                )
        }
        .buttonStyle(.plain)
        .foregroundStyle(Color.blueAccent)
    }
}

struct PrimaryActionButton: View {
    var title: String
    var systemImage: String = "arrow.right"
    var color: Color = .blueAccent
    var cornerRadius: CGFloat = 16
    var iconOnLeading = false
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                if iconOnLeading {
                    Image(systemName: systemImage)
                        .font(.system(size: 14, weight: .black))
                    Text(title)
                        .font(.system(size: 15, weight: .black))
                } else {
                    Text(title)
                        .font(.system(size: 15, weight: .black))
                    Image(systemName: systemImage)
                        .font(.system(size: 14, weight: .black))
                }
            }
            .foregroundStyle(Color.white)
            .frame(maxWidth: .infinity)
            .frame(height: 52)
            .background(color)
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            .shadow(color: color.opacity(0.22), radius: 12, y: 8)
        }
        .buttonStyle(.plain)
    }
}

struct SectionIntro: View {
    var title: String
    var bodyText: String

    var body: some View {
        AppCard {
            Text(title)
                .font(.system(size: 15, weight: .bold))
                .foregroundStyle(Color.navyPrimary)
            Text(bodyText)
                .font(.system(size: 11))
                .foregroundStyle(Color.slateTextLight)
                .lineSpacing(3)
        }
    }
}

struct OptionChip: View {
    var title: String
    var isSelected: Bool
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 10) {
                ZStack {
                    Circle()
                        .stroke(isSelected ? Color.navyPrimary : Color.slateMuted, lineWidth: 1.5)
                        .frame(width: 19, height: 19)
                    if isSelected {
                        Circle()
                            .fill(Color.navyPrimary)
                            .frame(width: 10, height: 10)
                    }
                }
                Text(title)
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(isSelected ? Color.navyPrimary : Color.slateTextDark)
                    .lineLimit(2)
                    .minimumScaleFactor(0.78)
                    .frame(maxWidth: .infinity, alignment: .leading)
                if isSelected {
                    Image(systemName: "checkmark")
                        .font(.system(size: 12, weight: .black))
                        .foregroundStyle(Color.navyPrimary)
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 11)
            .frame(maxWidth: .infinity)
            .background(isSelected ? Color.navyPrimary.opacity(0.08) : Color.slateLight)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(isSelected ? Color.navyPrimary : Color.clear, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}

struct OptionRow: View {
    var options: [(String, String)]
    var selected: String
    var onSelect: (String) -> Void

    var body: some View {
        VStack(spacing: 8) {
            ForEach(options, id: \.0) { key, title in
                OptionChip(title: title, isSelected: selected == key) {
                    onSelect(key)
                }
            }
        }
    }
}

struct HorizontalToggleRow: View {
    var options: [(String, String)]
    var selected: String
    var onSelect: (String) -> Void

    var body: some View {
        HStack(spacing: 4) {
            ForEach(options, id: \.0) { key, title in
                let isSelected = selected == key
                Button {
                    onSelect(key)
                } label: {
                    Text(title)
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(isSelected ? Color.white : Color.slateTextLight)
                        .lineLimit(2)
                        .minimumScaleFactor(0.72)
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 9)
                        .padding(.horizontal, 6)
                        .background(isSelected ? Color.navyPrimary : Color.clear)
                        .clipShape(RoundedRectangle(cornerRadius: 9, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(4)
        .background(Color.slateLight)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

struct CompactOptionButton: View {
    var title: String
    var subtitle: String?
    var isSelected: Bool
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 2) {
                Text(title)
                    .font(.system(size: 12, weight: .black))
                if let subtitle {
                    Text(subtitle)
                        .font(.system(size: 8, weight: .bold))
                        .opacity(isSelected ? 0.82 : 0.7)
                }
            }
            .foregroundStyle(isSelected ? Color.white : Color.navyMedium)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 8)
            .background(isSelected ? Color.navyPrimary : Color.slateLight)
            .clipShape(RoundedRectangle(cornerRadius: 9, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}

struct CompactOptionRow: View {
    var options: [(String, String, String?)]
    var selected: String
    var onSelect: (String) -> Void

    var body: some View {
        HStack(spacing: 5) {
            ForEach(options, id: \.0) { key, title, subtitle in
                CompactOptionButton(title: title, subtitle: subtitle, isSelected: selected == key) {
                    onSelect(key)
                }
            }
        }
        .padding(3)
        .background(Color.slateLight)
        .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 11).stroke(Color.slateBorder, lineWidth: 1))
    }
}

struct SelectableCardGrid: View {
    var options: [(key: String, title: String, subtitle: String)]
    var selected: String
    var columns: Int = 2
    var selectedFill: Color = .navyPrimary
    var selectedText: Color = .white
    var onSelect: (String) -> Void

    var body: some View {
        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: columns), spacing: 10) {
            ForEach(options, id: \.key) { option in
                let isSelected = selected == option.key
                Button {
                    onSelect(option.key)
                } label: {
                    VStack(spacing: 4) {
                        Text(option.title)
                            .font(.system(size: 12, weight: .black))
                            .foregroundStyle(isSelected ? selectedText : Color.navyPrimary)
                            .multilineTextAlignment(.center)
                            .lineLimit(2)
                            .minimumScaleFactor(0.76)
                        Text(option.subtitle)
                            .font(.system(size: 10, weight: .medium))
                            .foregroundStyle(isSelected ? selectedText.opacity(0.82) : Color.slateTextLight)
                            .multilineTextAlignment(.center)
                            .lineLimit(2)
                            .minimumScaleFactor(0.75)
                    }
                    .frame(maxWidth: .infinity, minHeight: 74)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 12)
                    .background(isSelected ? selectedFill : Color.slate50)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(isSelected ? selectedFill : Color.slateBorder, lineWidth: 1)
                    )
                }
                .buttonStyle(.plain)
            }
        }
    }
}

struct NumberCircle: View {
    var number: Int
    var isSelected: Bool
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Text("\(number)")
                .font(.system(size: 13, weight: .black))
                .foregroundStyle(isSelected ? Color.white : Color.slateTextDark)
                .frame(width: 44, height: 44)
                .background(isSelected ? Color.navyPrimary : Color.slateLight)
                .clipShape(Circle())
        }
        .frame(maxWidth: .infinity)
        .buttonStyle(.plain)
    }
}

struct StyledTextField: View {
    var title: String
    var placeholder: String
    var suffix: String?
    @Binding var text: String
    var decimal = false
    var leadingSystemImage: String?
    var trailingSystemImage: String?
    var trailingColor: Color = .navyPrimary

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(Color.slateTextLight)
            HStack(spacing: 8) {
                if let leadingSystemImage {
                    Image(systemName: leadingSystemImage)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(Color.navyMedium)
                }
                TextField(placeholder, text: $text)
                    .font(.system(size: 15, weight: .medium))
                    .keyboardType(decimal ? .decimalPad : .numberPad)
                    .textInputAutocapitalization(.never)
                if let trailingSystemImage {
                    Image(systemName: trailingSystemImage)
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(trailingColor)
                }
                if let suffix {
                    Text(suffix)
                        .font(.system(size: 11, weight: .black))
                        .foregroundStyle(Color.navyPrimary)
                }
            }
            .padding(.horizontal, 12)
            .frame(height: 48)
            .background(Color.slate50)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(Color.slateBorder, lineWidth: 1)
            )
        }
    }
}

struct ToggleLine: View {
    var title: String
    @Binding var isOn: Bool

    var body: some View {
        Toggle(isOn: $isOn) {
            Text(title)
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(Color.slateTextDark)
        }
        .tint(.blueAccent)
    }
}

struct AndroidToggleCard: View {
    var icon: String
    var title: String
    var subtitle: String?
    @Binding var isOn: Bool

    var body: some View {
        Button {
            isOn.toggle()
        } label: {
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(isOn ? Color.navyPrimary : Color.slateMuted)
                    .frame(width: 22)
                VStack(alignment: .leading, spacing: 3) {
                    Text(title)
                        .font(.system(size: 12, weight: .black))
                        .foregroundStyle(Color.slateTextDark)
                    if let subtitle {
                        Text(subtitle)
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundStyle(Color.blueAccent)
                            .lineLimit(2)
                            .minimumScaleFactor(0.8)
                    }
                }
                Spacer()
                Toggle("", isOn: $isOn)
                    .labelsHidden()
                    .tint(.blueAccent)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 11)
            .background(isOn ? Color.navyPrimary.opacity(0.05) : Color.slate50)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(isOn ? Color.navyPrimary.opacity(0.3) : Color.slateBorder, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}

struct BorderedPillButton: View {
    var title: String
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 11, weight: .black))
                .foregroundStyle(Color.blueAccent)
                .padding(.horizontal, 12)
                .padding(.vertical, 7)
                .background(Color.slateLight)
                .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.slateBorder, lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}
