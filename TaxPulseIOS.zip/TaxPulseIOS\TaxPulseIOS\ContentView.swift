import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        Group {
            if state.onboardingStep < 4 {
                OnboardingHost()
            } else {
                CalculatorShell()
            }
        }
        .environment(\.layoutDirection, state.language == .arabic ? .rightToLeft : .leftToRight)
    }
}

struct OnboardingHost: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.027, green: 0.043, blue: 0.098), Color(red: 0.118, green: 0.161, blue: 0.231)], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()

            switch state.onboardingStep {
            case 1:
                WelcomeScreen()
                    .transition(.move(edge: .trailing).combined(with: .opacity))
            case 2:
                LanguageScreen()
                    .transition(.move(edge: .trailing).combined(with: .opacity))
            default:
                ServiceScreen()
                    .transition(.move(edge: .trailing).combined(with: .opacity))
            }
        }
        .animation(.easeInOut(duration: 0.32), value: state.onboardingStep)
    }
}

struct WelcomeScreen: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        VStack(spacing: 34) {
            Spacer()
            VStack(spacing: 20) {
                TaxPulseLogo(size: 92)
                VStack(spacing: 12) {
                    Text(state.language == .arabic ? "مرحباً بك في Tax Pulse" : "Welcome to Tax Pulse")
                        .font(.system(size: 30, weight: .black))
                        .foregroundStyle(
                            LinearGradient(colors: [.white, Color(red: 0.576, green: 0.773, blue: 0.992), .blueAccent], startPoint: .leading, endPoint: .trailing)
                        )
                        .multilineTextAlignment(.center)
                    Text(state.language == .arabic ? "تبسيط أذكى للضرائب من أجلك." : "Smarter tax simplified for you.")
                        .font(.system(size: 15, weight: .medium))
                        .foregroundStyle(Color.slateMuted)
                    HeartRateLine()
                        .frame(height: 72)
                        .padding(.vertical, 6)
                    Rectangle()
                        .fill(Color.white.opacity(0.14))
                        .frame(width: 96, height: 1)
                    Text(Copy.t("contact", state.language))
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(Color(red: 0.376, green: 0.647, blue: 0.980))
                    Text(Copy.t("contactSub", state.language))
                        .font(.system(size: 10))
                        .foregroundStyle(Color.white.opacity(0.58))
                }
                .padding(26)
                .frame(maxWidth: .infinity)
                .background(Color.white.opacity(0.04))
                .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.09), lineWidth: 1))
                .background(
                    RadialGradient(
                        colors: [Color.blueAccent.opacity(0.34), Color.navyMedium.opacity(0.14), Color.clear],
                        center: .center,
                        startRadius: 12,
                        endRadius: 240
                    )
                    .frame(width: 390, height: 390)
                    .blur(radius: 12)
                )
            }
            .padding(.horizontal, 24)

            PrimaryActionButton(title: state.language == .arabic ? "دخول" : "ENTER", color: .blueAccent, cornerRadius: 29) {
                state.onboardingStep = 2
            }
            .padding(.horizontal, 46)
            Spacer()
        }
    }
}

struct LanguageScreen: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        VStack(spacing: 28) {
            TopBackButton { state.onboardingStep = 1 }
            Spacer()
            Image(systemName: "globe")
                .font(.system(size: 58, weight: .semibold))
                .foregroundStyle(Color(red: 0.376, green: 0.647, blue: 0.980))
            VStack(spacing: 8) {
                Text(state.language == .arabic ? "اختر لغتك المفضلة" : "Choose the language")
                    .font(.system(size: 24, weight: .black))
                    .foregroundStyle(Color.white)
                Text(state.language == .arabic ? "يمكنك تغيير هذا الخيار لاحقا" : "You can change this anytime later")
                    .font(.system(size: 14))
                    .foregroundStyle(Color.slateMuted)
            }
            HStack(spacing: 16) {
                LanguageCard(title: "English", subtitle: "Smarter tax simplified", code: "EN", selected: state.language == .english) {
                    state.language = .english
                    state.onboardingStep = 3
                }
                LanguageCard(title: "العربية", subtitle: "الضرائب الذكية مبسطة", code: "AR", selected: state.language == .arabic) {
                    state.language = .arabic
                    state.onboardingStep = 3
                }
            }
            .padding(.horizontal, 24)
            Spacer()
        }
    }
}

struct ServiceScreen: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        VStack(spacing: 24) {
            TopBackButton { state.onboardingStep = 2 }
            Spacer()
            VStack(spacing: 8) {
                Text(state.language == .arabic ? "اختر نوع الخدمة المطلوبة" : "Choose your service")
                    .font(.system(size: 24, weight: .black))
                    .foregroundStyle(Color.white)
                Text(state.language == .arabic ? "اختر خدمة للبدء مباشرة" : "Select a service below to jump straight in")
                    .font(.system(size: 13))
                    .foregroundStyle(Color.slateMuted)
                    .multilineTextAlignment(.center)
            }
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                ServiceSelectionCard(tab: .payroll, color: .blueAccent, icon: "banknote.fill") { state.chooseService(.payroll) }
                ServiceSelectionCard(tab: .profit, color: .successGreen, icon: "building.columns.fill") { state.chooseService(.profit) }
                ServiceSelectionCard(tab: .penalties, color: .alertGold, icon: "exclamationmark.triangle.fill") { state.chooseService(.penalties) }
                ServiceSelectionCard(tab: .extensions, color: Color(red: 0.925, green: 0.282, blue: 0.600), icon: "calendar.badge.clock") { state.chooseService(.extensions) }
            }
            .padding(.horizontal, 24)
            Spacer()
        }
    }
}

struct CalculatorShell: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                HeaderView()
                ActiveServiceBanner()

                switch state.selectedTab {
                case .payroll: PayrollCalculatorTab()
                case .profit: ProfitCalculatorTab()
                case .penalties: PenaltiesCalculatorTab()
                case .extensions: ExtensionsCalculatorTab()
                }

                ContactCard()
            }
            .padding(16)
        }
        .background(Color.slateLight.ignoresSafeArea())
    }
}

struct HeaderView: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 3) {
                Text(Copy.t("headerTitle", state.language))
                    .font(.system(size: 18, weight: .black))
                    .foregroundStyle(Color.navyPrimary)
                Text(Copy.t("byHaddad", state.language))
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(Color.navyMedium)
                    .lineLimit(1)
                Text(Copy.t("subtitle", state.language))
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(Color.blueAccent)
                    .lineLimit(1)
            }
            Spacer()
            HorizontalToggleRow(options: [("EN", "ENG"), ("AR", "ARB")], selected: state.language.rawValue) { key in
                state.language = key == "AR" ? .arabic : .english
            }
            .frame(width: 146)
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        }
    }
}

struct ActiveServiceBanner: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        let meta = serviceMeta(state.selectedTab, language: state.language)
        HStack(spacing: 12) {
            Image(systemName: meta.icon)
                .font(.system(size: 17, weight: .bold))
                .foregroundStyle(Color.white)
                .frame(width: 36, height: 36)
                .background(meta.color)
                .clipShape(Circle())
            VStack(alignment: .leading, spacing: 3) {
                Text(Copy.t("activeService", state.language))
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(Color.slateTextLight)
                Text(meta.title)
                    .font(.system(size: 15, weight: .black))
                    .foregroundStyle(Color.navyPrimary)
            }
            Spacer()
            Button(Copy.t("changeService", state.language)) {
                state.onboardingStep = 3
            }
            .font(.system(size: 12, weight: .black))
            .foregroundStyle(Color.blueAccent)
        }
        .padding(14)
        .background(meta.color.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(meta.color.opacity(0.25), lineWidth: 1)
        )
    }
}

struct PayrollCalculatorTab: View {
    @EnvironmentObject private var state: AppState
    @State private var isCalculated = false

    var body: some View {
        VStack(spacing: 16) {
            SectionIntro(
                title: Copy.t("payrollIntroTitle", state.language),
                bodyText: Copy.t("payrollIntroBody", state.language)
            )

            AppCard {
                HStack {
                    Text(Copy.t("payroll", state.language))
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(Color.navyPrimary)
                    Spacer()
                    PillButton(title: Copy.t("reset", state.language), systemImage: "arrow.clockwise") {
                        isCalculated = false
                        state.resetPayroll()
                    }
                }

                Text(Copy.t("salaryPeriod", state.language))
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(Color.slateTextLight)
                HorizontalToggleRow(options: [("MONTHLY", Copy.t("monthly", state.language)), ("ANNUAL", Copy.t("annual", state.language))], selected: state.salaryPeriod.rawValue) {
                    state.salaryPeriod = $0 == "ANNUAL" ? .annual : .monthly
                    isCalculated = false
                }

                Text(Copy.t("currency", state.language))
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(Color.slateTextLight)
                HorizontalToggleRow(options: [("LBP", Copy.t("lbp", state.language)), ("USD", Copy.t("usd", state.language))], selected: state.payrollCurrency.rawValue) {
                    state.payrollCurrency = $0 == "USD" ? .usd : .lbp
                    isCalculated = false
                }

                if state.payrollCurrency == .lbp {
                    StyledTextField(title: state.salaryPeriod == .annual ? Copy.t("annualSalaryLbp", state.language) : Copy.t("basicSalaryLbp", state.language), placeholder: Copy.t("enterSalary", state.language), suffix: state.language == .arabic ? "ل.ل" : "LBP", text: Binding(get: { state.payrollGrossLbp }, set: { state.payrollGrossLbp = sanitizedDigits($0); isCalculated = false }), leadingSystemImage: "creditcard.fill")
                    Text("\(Copy.t("currentValue", state.language)) \(money(result: Double(state.payrollGrossLbp) ?? 0, language: state.language))")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle((Double(state.payrollGrossLbp) ?? 0) > 0 ? Color.successGreen : Color.slateTextLight)
                } else {
                    StyledTextField(title: state.salaryPeriod == .annual ? Copy.t("annualSalaryUsd", state.language) : Copy.t("monthlyUsd", state.language), placeholder: "e.g. 1500", suffix: "USD", text: Binding(get: { state.payrollGrossUsd }, set: { state.payrollGrossUsd = sanitizedDecimal($0); isCalculated = false }), decimal: true, leadingSystemImage: "creditcard.fill")
                    StyledTextField(title: Copy.t("customRate", state.language), placeholder: "e.g. 89,500", suffix: state.language == .arabic ? "ل.ل/$" : "LBP/USD", text: Binding(get: { state.payrollExchangeRate }, set: { state.payrollExchangeRate = sanitizedDecimal($0); isCalculated = false }), decimal: true)
                    BorderedPillButton(title: Copy.t("useStandardRate", state.language)) {
                        state.payrollExchangeRate = "89500"
                    }
                    Text("\(Copy.t("equivalentLbp", state.language)) \(money(result: state.payrollBasicSalaryLbpValue, language: state.language))")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(state.payrollBasicSalaryLbpValue > 0 ? Color.successGreen : Color.slateTextLight)
                }

                OptionRow(
                    options: [
                        ("SINGLE", Copy.t("single", state.language)),
                        ("SPOUSE_DEPENDENT", Copy.t("spouseDependent", state.language)),
                        ("SPOUSE_WORKS", Copy.t("spouseWorks", state.language)),
                        ("DIVORCED", Copy.t("divorced", state.language)),
                        ("WIDOWED", Copy.t("widowed", state.language))
                    ],
                    selected: state.payrollMarital.rawValue
                ) {
                    state.payrollMarital = MaritalStatus(rawValue: $0) ?? .single
                    if state.payrollMarital == .single { state.payrollChildren = 0 }
                    isCalculated = false
                }

                if state.payrollMarital != .single {
                    ChildrenPicker(count: $state.payrollChildren)
                }

                AndroidToggleCard(icon: "shield.fill", title: Copy.t("nssfReg", state.language), subtitle: nil, isOn: $state.isNssfRegistered)
                AndroidToggleCard(icon: "person.2.fill", title: Copy.t("familyRebates", state.language), subtitle: Copy.t("familyRebatesSub", state.language), isOn: $state.useFamilyRebates)

                if state.salaryPeriod == .annual {
                    Text(Copy.t("annualNssfCeiling", state.language))
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(Color.slateTextLight)
                    StyledTextField(title: Copy.t("annualSicknessCeiling", state.language), placeholder: Copy.t("optional", state.language), suffix: state.language == .arabic ? "ل.ل" : "LBP", text: Binding(get: { state.sicknessCeilingOverride }, set: { state.sicknessCeilingOverride = sanitizedDigits($0) }))
                    StyledTextField(title: Copy.t("annualFamilyCeiling", state.language), placeholder: Copy.t("optional", state.language), suffix: state.language == .arabic ? "ل.ل" : "LBP", text: Binding(get: { state.familyCeilingOverride }, set: { state.familyCeilingOverride = sanitizedDigits($0) }))
                }
            }

            if state.payrollGrossLbpValue > 0 && !isCalculated {
                PrimaryActionButton(title: Copy.t("calculate", state.language)) {
                    isCalculated = true
                }
            }

            if isCalculated {
                PayrollResultCard(result: state.payrollResult)
            }
        }
    }
}

struct PayrollResultCard: View {
    @EnvironmentObject private var state: AppState
    var result: PayrollItem

    var body: some View {
        AppCard {
            Text(Copy.t("complianceSummary", state.language))
                .font(.system(size: 15, weight: .black))
                .foregroundStyle(Color.navyPrimary)

            VStack(spacing: 8) {
                Text(state.salaryPeriod == .annual ? (state.language == .arabic ? "صافي الراتب السنوي للقبض" : "ANNUAL NET TO BE CASHED") : Copy.t("netWithFamily", state.language).uppercased())
                    .font(.system(size: 12, weight: .black))
                    .foregroundStyle(Color.navyPrimary)
                    .multilineTextAlignment(.center)
                Text(money(result: result.netSalary, language: state.language))
                    .font(.system(size: 28, weight: .black))
                    .foregroundStyle(Color.successGreen)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
                Text(Copy.t("basedOnEmployee", state.language))
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(Color.slateTextDark)
            }
            .frame(maxWidth: .infinity)
            .padding(16)
            .background(Color.slateLight)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.slateBorder, lineWidth: 1))

            ResultRow(title: state.salaryPeriod == .annual ? Copy.t("annualGrossSalary", state.language) : Copy.t("baseMonthly", state.language), value: money(result: result.basicSalary, language: state.language))
            TaxHighlightRow(title: state.salaryPeriod == .annual ? (state.language == .arabic ? "ضريبة الرواتب السنوية" : "Annual Salary Income Tax") : Copy.t("mofTax", state.language), value: signedMoney(result.taxAmount, isDeduction: true, language: state.language), hasTax: result.taxAmount > 0)
            ResultRow(title: state.salaryPeriod == .annual ? (state.language == .arabic ? "الضمان الصحي السنوي (الموظف)" : "Annual Sickness & Maternity NSSF") : Copy.t("sicknessNssf", state.language), value: signedMoney(result.sicknessMaternityEmployee, isDeduction: true, language: state.language), valueColor: result.sicknessMaternityEmployee > 0 ? .dangerRed : .slateTextDark)
            ResultRow(title: state.salaryPeriod == .annual ? (state.language == .arabic ? "التعويضات السنوية العائلية" : "Annual Family Allowances") : Copy.t("familyAllowances", state.language), value: signedMoney(result.totalFamilyBenefitsAmount, isDeduction: false, language: state.language), valueColor: result.totalFamilyBenefitsAmount > 0 ? .successGreen : .slateTextDark)
            ResultRow(title: Copy.t("taxableSalaryAfterRebates", state.language), value: money(result: result.taxableSalary, language: state.language), isBold: true)
            ResultRow(title: Copy.t("totalFamilyRebates", state.language), value: money(result: result.familyRebatesAmount, language: state.language))

            let periodMultiplier = state.salaryPeriod == .annual ? 12.0 : 1.0
            let sicknessCeiling = (Double(state.sicknessCeilingOverride) ?? (state.payrollMonth <= 7 ? 90_000_000 : 120_000_000)) * periodMultiplier
            let familyCeiling = (Double(state.familyCeilingOverride) ?? (state.payrollMonth <= 6 ? 12_000_000 : 28_000_000)) * periodMultiplier
            Text(state.salaryPeriod == .annual ? (state.language == .arabic ? "تفاصيل اشتراكات الضمان الاجتماعي السنوية (ل.ل)" : "Annual NSSF Branches & Contributions (LBP)") : Copy.t("nssfBranches", state.language))
                .font(.system(size: 14, weight: .black))
                .foregroundStyle(Color.navyPrimary)
                .padding(.top, 8)
            NssfBranchCard(title: Copy.t("sicknessBranch", state.language), base: result.sicknessMaternityBase, ceiling: sicknessCeiling, employee: result.sicknessMaternityEmployee, employer: result.sicknessMaternityEmployer, employerRate: "8%", employeeRate: "3%", language: state.language)
            NssfBranchCard(title: Copy.t("familyBranch", state.language), base: result.familyAllowanceBase, ceiling: familyCeiling, employee: 0, employer: result.familyAllowanceEmployer, employerRate: "6%", employeeRate: "0%", language: state.language)
            NssfBranchCard(title: Copy.t("endServiceBranch", state.language), base: result.endOfServiceBase, ceiling: 0, employee: 0, employer: result.endOfServiceEmployer, employerRate: "8.5%", employeeRate: "0%", language: state.language)

            EmployerCostBox(result: result, language: state.language)

            if result.hasMinimumWageWarning {
                let wage = state.payrollMonth <= 7 ? "18,000,000 LBP" : "28,000,000 LBP"
                ComplianceBanner(
                    systemImage: "exclamationmark.triangle.fill",
                    title: Copy.t("warningCount", state.language),
                    text: Copy.t("warningDesc", state.language).replacingOccurrences(of: "%@", with: state.language == .arabic ? wage.replacingOccurrences(of: "LBP", with: "ل.ل") : wage),
                    color: .alertGold,
                    background: .alertGoldBg
                )
            } else {
                ComplianceBanner(
                    systemImage: "checkmark.seal.fill",
                    title: Copy.t("secureCount", state.language),
                    text: Copy.t("secureDesc", state.language),
                    color: .successGreen,
                    background: .successGreenBg
                )
            }
        }
    }
}

struct ProfitCalculatorTab: View {
    @EnvironmentObject private var state: AppState
    @State private var isCalculated = false

    var body: some View {
        VStack(spacing: 16) {
            SectionIntro(title: Copy.t("profitIntroTitle", state.language), bodyText: Copy.t("profitIntroBody", state.language))

            AppCard {
                HStack {
                    Text(Copy.t("profit", state.language))
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(Color.navyPrimary)
                    Spacer()
                    PillButton(title: Copy.t("reset", state.language), systemImage: "arrow.clockwise") {
                        state.profitGrossLbp = ""
                        state.profitGrossUsd = ""
                        state.profitCurrency = .lbp
                        state.profitExchangeRate = ""
                        state.profitMarital = .single
                        state.profitChildren = 0
                        state.profitOwnerName = ""
                        isCalculated = false
                    }
                }

                Text(Copy.t("currency", state.language))
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(Color.slateTextLight)
                OptionRow(options: [("LBP", Copy.t("lbp", state.language)), ("USD", Copy.t("usd", state.language))], selected: state.profitCurrency.rawValue) {
                    state.profitCurrency = $0 == "USD" ? .usd : .lbp
                    isCalculated = false
                }

                if state.profitCurrency == .lbp {
                    StyledTextField(title: "\(Copy.t("annualNetProfit", state.language)) \(state.language == .arabic ? "(ل.ل)" : "(LBP)")", placeholder: Copy.t("enterAnnualNetProfit", state.language), suffix: state.language == .arabic ? "ل.ل" : "LBP", text: Binding(get: { state.profitGrossLbp }, set: { state.profitGrossLbp = sanitizedDigits($0); isCalculated = false }), trailingSystemImage: "chart.line.uptrend.xyaxis", trailingColor: .successGreen)
                } else {
                    StyledTextField(title: "\(Copy.t("annualNetProfit", state.language)) \(state.language == .arabic ? "(دولار)" : "(USD)")", placeholder: Copy.t("enterAnnualNetProfit", state.language), suffix: "USD", text: Binding(get: { state.profitGrossUsd }, set: { state.profitGrossUsd = sanitizedDecimal($0); isCalculated = false }), decimal: true, trailingSystemImage: "chart.line.uptrend.xyaxis", trailingColor: .successGreen)
                    StyledTextField(title: Copy.t("customRate", state.language), placeholder: "e.g. 89,500", suffix: state.language == .arabic ? "ل.ل/$" : "LBP/$", text: Binding(get: { state.profitExchangeRate }, set: { state.profitExchangeRate = sanitizedDecimal($0); isCalculated = false }), decimal: true)
                    BorderedPillButton(title: Copy.t("useStandardRate", state.language)) { state.profitExchangeRate = "89500" }
                }

                Text(Copy.t("marital", state.language))
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(Color.slateTextLight)
                OptionRow(
                    options: [
                        ("SINGLE", Copy.t("single", state.language)),
                        ("SPOUSE_DEPENDENT", Copy.t("spouseDependent", state.language)),
                        ("SPOUSE_WORKS", Copy.t("spouseWorks", state.language)),
                        ("DIVORCED", Copy.t("divorced", state.language)),
                        ("WIDOWED", Copy.t("widowed", state.language))
                    ],
                    selected: state.profitMarital.rawValue
                ) {
                    state.profitMarital = MaritalStatus(rawValue: $0) ?? .single
                    if state.profitMarital == .single { state.profitChildren = 0 }
                    isCalculated = false
                }

                if state.profitMarital != .single {
                    ChildrenPicker(count: $state.profitChildren)
                }
            }

            if state.profitMarital == .spouseWorks && state.profitChildren > 0 {
                WarningBox(title: "", text: Copy.t("splitWarning", state.language))
            }

            if hasProfitInput && !isCalculated {
                PrimaryActionButton(title: Copy.t("calculateProfit", state.language)) { isCalculated = true }
            }

            if isCalculated {
                ProfitResultCard(result: state.profitResult)
            }
        }
    }

    private var hasProfitInput: Bool {
        state.profitCurrency == .lbp ? !state.profitGrossLbp.isEmpty : !state.profitGrossUsd.isEmpty
    }
}

struct ProfitResultCard: View {
    @EnvironmentObject private var state: AppState
    var result: ProfitTaxResult

    var body: some View {
        AppCard {
            VStack(alignment: .leading, spacing: 3) {
                Text(Copy.t("profitSummary", state.language))
                    .font(.system(size: 14, weight: .black))
                    .foregroundStyle(Color.navyPrimary)
                Text(Copy.t("profitDisclaimer", state.language))
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(Color.slateTextLight)
            }

            VStack(spacing: 8) {
                Text(Copy.t("totalTaxDue", state.language))
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(Color.slateTextDark)
                Text(money(result: result.totalTaxDue, language: state.language))
                    .font(.system(size: 25, weight: .black))
                    .foregroundStyle(Color(red: 0.761, green: 0.063, blue: 0.063))
                Divider()
                Text(Copy.t("remainingNetProfit", state.language))
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(Color.slateTextDark)
                Text(money(result: result.netNetProfit, language: state.language))
                    .font(.system(size: 18, weight: .black))
                    .foregroundStyle(Color.successGreen)
            }
            .frame(maxWidth: .infinity)
            .padding(16)
            .background(Color.slateLight)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.slateBorder, lineWidth: 1))

            Text(Copy.t("totalFamilyRebates", state.language))
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(Color.navyPrimary)
            ResultRow(title: Copy.t("rebateHimself", state.language), value: money(result: result.himselfRebate, language: state.language))
            if result.spouseRebate > 0 {
                ResultRow(title: Copy.t("rebateWife", state.language), value: money(result: result.spouseRebate, language: state.language))
            }
            if result.childrenRebate > 0 {
                ResultRow(title: Copy.t("rebateChildren", state.language), value: money(result: result.childrenRebate, language: state.language))
            }
            Divider()
            ResultRow(title: Copy.t("totalAnnualDeductibleRebate", state.language), value: money(result: result.totalRebates, language: state.language), valueColor: .navyPrimary, isBold: true)
            ResultRow(title: Copy.t("taxableProfitAfterRebates", state.language), value: money(result: result.profitAfterRebates, language: state.language), isBold: true)

            Text(Copy.t("profitBracketsDetail", state.language))
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(Color.navyPrimary)
                .padding(.top, 8)
            ForEach(result.bracketAllocations) { bracket in
                BracketRowView(bracket: bracket, total: result.profitAfterRebates, language: state.language)
            }
        }
    }
}

struct PenaltiesCalculatorTab: View {
    @EnvironmentObject private var state: AppState
    @State private var isCalculated = false

    var body: some View {
        VStack(spacing: 16) {
            SectionIntro(title: Copy.t("penaltiesIntroTitle", state.language), bodyText: Copy.t("penaltiesIntroBody", state.language))

            AppCard {
                HStack {
                    Text(Copy.t("penaltiesIntroTitle", state.language))
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(Color.navyPrimary)
                    Spacer()
                    PillButton(title: Copy.t("reset", state.language), systemImage: "arrow.clockwise") {
                        state.penaltyCompanyType = "SAL"
                        state.penaltyTaxType = "PAYROLL"
                        state.penaltyAmount = ""
                        state.penaltyPayrollYear = "2026"
                        state.penaltyQuarter = "Q1"
                        state.penaltyProfitYear = "2026"
                        state.syncPenaltyDueDate()
                        isCalculated = false
                    }
                }

                HorizontalToggleRow(options: [("PAYROLL", Copy.t("payrollTax", state.language)), ("PROFIT", Copy.t("profit", state.language)), ("VAT", Copy.t("vatPenalties", state.language))], selected: state.penaltyTaxType) {
                    state.penaltyTaxType = $0
                    state.syncPenaltyDueDate()
                    isCalculated = false
                }

                SelectableCardGrid(options: penaltyCompanyOptions, selected: state.penaltyCompanyType) {
                    state.penaltyCompanyType = $0
                    state.syncPenaltyDueDate()
                    isCalculated = false
                }

                StyledTextField(title: Copy.t("taxAmount", state.language), placeholder: Copy.t("enterTaxAmount", state.language), suffix: state.language == .arabic ? "ل.ل" : "LBP", text: Binding(get: { state.penaltyAmount }, set: { state.penaltyAmount = sanitizedDigits($0); isCalculated = false }))
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "info.circle.fill")
                        .foregroundStyle(Color.orange800)
                    Text(Copy.t("zeroTaxNote", state.language))
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(Color.orange800)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.orange50)
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.orange100, lineWidth: 1))
                Text("\(Copy.t("currentValueLower", state.language)) \(money(result: Double(state.penaltyAmount) ?? 0, language: state.language))")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(Color.slateTextLight)

                if state.penaltyTaxType == "PAYROLL" || state.penaltyTaxType == "VAT" {
                    StyledTextField(title: Copy.t("year", state.language), placeholder: "2026", suffix: nil, text: Binding(get: { state.penaltyPayrollYear }, set: { state.penaltyPayrollYear = sanitizedDigits($0); state.syncPenaltyDueDate(); isCalculated = false }))
                    CompactOptionRow(options: penaltyQuarterOptions, selected: state.penaltyQuarter) {
                        state.penaltyQuarter = $0
                        state.syncPenaltyDueDate()
                        isCalculated = false
                    }
                } else {
                    StyledTextField(title: Copy.t("profitDueYear", state.language), placeholder: "2026", suffix: nil, text: Binding(get: { state.penaltyProfitYear }, set: { state.penaltyProfitYear = sanitizedDigits($0); state.syncPenaltyDueDate(); isCalculated = false }))
                }

                DateFields(title: state.language == .arabic ? "تاريخ الاستحقاق القانوني" : "Statutory Due Date", day: $state.penaltyDueDay, month: $state.penaltyDueMonth, year: $state.penaltyDueYear, showsTitle: false)
                Button {
                    prefillPenaltyAutoDate()
                    isCalculated = false
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "calendar.badge.clock")
                            .font(.system(size: 16, weight: .bold))
                        Text(Copy.t("standardDueDate", state.language).replacingOccurrences(of: "%@", with: formattedPenaltyAutoDate))
                            .font(.system(size: 12, weight: .black))
                            .multilineTextAlignment(.leading)
                        Spacer()
                    }
                    .foregroundStyle(Color.blueAccent)
                    .padding(12)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.blueAccent.opacity(0.08))
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.blueAccent.opacity(0.25), lineWidth: 1))
                }
                .buttonStyle(.plain)
                DateFields(title: Copy.t("paymentDate", state.language), day: $state.penaltyPayDay, month: $state.penaltyPayMonth, year: $state.penaltyPayYear)
            }

            if !state.penaltyAmount.isEmpty && !isCalculated {
                PrimaryActionButton(title: Copy.t("calculatePenalties", state.language)) { isCalculated = true }
            }

            if isCalculated {
                PenaltyResultCard(result: state.penaltyResult)
            }
        }
    }

    private var penaltyCompanyOptions: [(key: String, title: String, subtitle: String)] {
        [
            ("SAL", state.language == .arabic ? "شركة مساهمة SAL" : "SAL Corporation", "\(state.language == .arabic ? "الحد الأدنى:" : "Min:") \(minFineText(for: "SAL")) \(state.language == .arabic ? "ل.ل" : "LBP")"),
            ("SARL", state.language == .arabic ? "شركة محدودة SARL" : "SARL (LLC)", "\(state.language == .arabic ? "الحد الأدنى:" : "Min:") \(minFineText(for: "SARL")) \(state.language == .arabic ? "ل.ل" : "LBP")"),
            ("PARTNERSHIP", state.language == .arabic ? "شركة أشخاص" : "Partnership", "\(state.language == .arabic ? "الحد الأدنى:" : "Min:") \(minFineText(for: "PARTNERSHIP")) \(state.language == .arabic ? "ل.ل" : "LBP")"),
            ("INDIVIDUAL", state.language == .arabic ? "مؤسسة فردية" : "Individual Enterprise", "\(state.language == .arabic ? "الحد الأدنى:" : "Min:") \(minFineText(for: "INDIVIDUAL")) \(state.language == .arabic ? "ل.ل" : "LBP")"),
            ("EXEMPT", state.language == .arabic ? "مؤسسة مستثناة" : "Exempt Institution", "\(state.language == .arabic ? "الحد الأدنى:" : "Min:") \(minFineText(for: "EXEMPT")) \(state.language == .arabic ? "ل.ل" : "LBP")"),
            ("OTHER", state.language == .arabic ? "مكلفون آخرون" : "Other Taxpayers", "\(state.language == .arabic ? "الحد الأدنى:" : "Min:") \(minFineText(for: "OTHER")) \(state.language == .arabic ? "ل.ل" : "LBP")")
        ]
    }

    private var penaltyQuarterOptions: [(String, String, String?)] {
        state.penaltyTaxType == "VAT"
            ? [("Q1", "Q1", "3/31"), ("Q2", "Q2", "6/30"), ("Q3", "Q3", "9/30"), ("Q4", "Q4", "12/31")]
            : [("Q1", "Q1", "3/31"), ("Q2", "Q2", "6/30"), ("Q3", "Q3", "9/30"), ("Q4", "Q4", "12/31"), ("R5", "R5", "Annual")]
    }

    private var penaltyAutoDate: ExtensionDateParts {
        TaxEngines.statutoryDueDate(
            taxType: state.penaltyTaxType,
            payrollYear: Int(state.penaltyPayrollYear) ?? 2026,
            quarter: state.penaltyQuarter,
            profitDueYear: Int(state.penaltyProfitYear) ?? 2026,
            companyType: state.penaltyCompanyType
        )
    }

    private var formattedPenaltyAutoDate: String {
        formatDateParts(penaltyAutoDate, language: state.language)
    }

    private func prefillPenaltyAutoDate() {
        let date = penaltyAutoDate
        state.penaltyDueDay = "\(date.day)"
        state.penaltyDueMonth = "\(date.month)"
        state.penaltyDueYear = "\(date.year)"
    }

    private func minFineText(for company: String) -> String {
        let selectedYear = (state.penaltyTaxType == "PAYROLL" || state.penaltyTaxType == "VAT")
            ? (Int(state.penaltyPayrollYear) ?? 2026)
            : (Int(state.penaltyProfitYear) ?? 2026)
        let legacy = selectedYear == 2024 || selectedYear == 2025
        switch company {
        case "SAL": return legacy ? "6.75M" : "18.75M"
        case "SARL", "PARTNERSHIP", "EXEMPT": return legacy ? "4.5M" : "12.5M"
        default: return legacy ? "750K" : "2.5M"
        }
    }
}

struct PenaltyResultCard: View {
    @EnvironmentObject private var state: AppState
    var result: PenaltyResult

    var body: some View {
        AppCard {
            VStack(spacing: 8) {
                Text(Copy.t("totalAmountDue", state.language))
                    .font(.system(size: 12, weight: .black))
                    .foregroundStyle(Color.slateTextDark)
                Text(money(result: result.totalAmount, language: state.language))
                    .font(.system(size: 26, weight: .black))
                    .foregroundStyle(Color.dangerRed)
                Text(Copy.t("lateMonthsCounted", state.language).replacingOccurrences(of: "%@", with: "\(result.lateMonths)"))
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(Color.slateTextLight)
            }
            .frame(maxWidth: .infinity)
            .padding(16)
            .background(Color.slateLight)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))

            ResultRow(title: Copy.t("minimumVerificationFine", state.language), value: money(result: result.minimumThreshold, language: state.language))
            ResultRow(title: Copy.t("verificationFine", state.language), value: money(result: result.verificationFine, language: state.language), valueColor: .dangerRed, isBold: true)
            ResultRow(title: Copy.t("collectionFine", state.language), value: money(result: result.collectionFine, language: state.language), valueColor: .dangerRed, isBold: true)
            if result.isDueDateAfterPayment {
                SuccessBox(title: state.language == .arabic ? "لا يوجد تأخير" : "No delay detected", text: state.language == .arabic ? "تاريخ الدفع واقع قبل أو في تاريخ الاستحقاق القانوني." : "The payment date is on or before the statutory due date.")
            } else if result.isUnderMinimum {
                WarningBox(title: state.language == .arabic ? "تم تطبيق الحد الأدنى" : "Minimum fine applied", text: state.language == .arabic ? "تم رفع غرامة التحقق إلى الحد الأدنى القانوني لفئة هذا المكلف." : "The verification fine was raised to the legal minimum for this taxpayer category.")
            } else if result.isCapped {
                WarningBox(title: state.language == .arabic ? "تم تحديد سقف الغرامة" : "Verification fine capped", text: state.language == .arabic ? "تم تحديد غرامة التحقق بنسبة 100% من أصل الضريبة." : "The verification fine was capped at 100% of the original tax.")
            }
        }
    }
}

struct ExtensionsCalculatorTab: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        VStack(spacing: 16) {
            SectionIntro(title: Copy.t("extensionsIntroTitle", state.language), bodyText: Copy.t("extensionsIntroBody", state.language))

            AppCard {
                Text(Copy.t("selectExtensionTaxType", state.language))
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(Color.slateTextDark)
                SelectableCardGrid(
                    options: [
                        ("PAYROLL", Copy.t("payrollTax", state.language), ""),
                        ("VAT", Copy.t("vat", state.language), ""),
                        ("PROFIT", Copy.t("profit", state.language), ""),
                        ("AUDIT", Copy.t("auditReport", state.language), "")
                    ],
                    selected: state.extensionTaxType,
                    selectedFill: .navyPrimary
                ) {
                    state.extensionTaxType = $0
                    state.syncExtensionDate()
                }

                VStack(alignment: .leading, spacing: 6) {
                    Text(Copy.t("fiscalYear", state.language))
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(Color.slateTextLight)
                    Picker(Copy.t("fiscalYear", state.language), selection: Binding(get: { state.extensionYear }, set: { state.extensionYear = $0; state.syncExtensionDate() })) {
                        ForEach(extensionYears, id: \.self) { year in
                            Text(year).tag(year)
                        }
                    }
                    .pickerStyle(.menu)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 12)
                    .frame(height: 46)
                    .background(Color.slateLight)
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.slateBorder, lineWidth: 1))
                }

                if state.extensionTaxType == "PAYROLL" || state.extensionTaxType == "VAT" {
                    Text(Copy.t("filingQuarter", state.language))
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(Color.slateTextLight)
                    CompactOptionRow(options: extensionQuarterOptions, selected: state.extensionQuarter) {
                        state.extensionQuarter = $0
                        state.syncExtensionDate()
                    }
                } else {
                    Text(state.extensionTaxType == "AUDIT" ? Copy.t("companyCategoryAudit", state.language) : Copy.t("companyCategoryProfit", state.language))
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(Color.slateTextDark)
                    SelectableCardGrid(options: extensionEntityOptions, selected: state.extensionCompanyType) {
                        state.extensionCompanyType = $0
                        state.syncExtensionDate()
                    }
                }

                let auto = state.extensionAutoDate
                HStack(alignment: .center, spacing: 12) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(Copy.t("primaryStatutoryDueDate", state.language))
                            .font(.system(size: 11, weight: .bold))
                            .foregroundStyle(Color.slateTextLight)
                        Text(Copy.t("originalDueDate", state.language))
                            .font(.system(size: 10, weight: .medium))
                            .foregroundStyle(Color.slateMuted)
                    }
                    Spacer()
                    Text(formatDateParts(auto, language: state.language))
                        .font(.system(size: 18, weight: .black))
                        .foregroundStyle(Color.navyPrimary)
                        .multilineTextAlignment(.trailing)
                }
                .padding(14)
                .background(Color.slateLight)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.slateBorder, lineWidth: 1))
                DateFields(title: Copy.t("officialExtendedDate", state.language), day: $state.extensionDay, month: $state.extensionMonth, year: $state.extensionYearValue)
                PrimaryActionButton(title: Copy.t("saveExtension", state.language), systemImage: "checkmark.circle.fill", color: .navyPrimary, cornerRadius: 12, iconOnLeading: true) {
                    state.saveExtension()
                }
            }

            AppCard {
                Text(Copy.t("retrieveExtensions", state.language))
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(Color.navyPrimary)
                Text(Copy.t("retrieveExtensionsBody", state.language))
                    .font(.system(size: 11))
                    .foregroundStyle(Color.slateTextLight)
                PrimaryActionButton(title: Copy.t("retrieveNow", state.language), systemImage: "arrow.clockwise", color: .blueAccent, cornerRadius: 12, iconOnLeading: true) {
                    state.retrieveExtension()
                }
                if let message = state.extensionMessage {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(Copy.t("retrievedRecord", state.language))
                            .font(.system(size: 11, weight: .bold))
                            .foregroundStyle(Color.slateTextDark)
                        Text(message)
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(message.contains("No registered") || message.contains("لا توجد") ? Color.orange800 : Color.successGreen)
                    }
                    .padding(14)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(message.contains("No registered") || message.contains("لا توجد") ? Color.orange50 : Color.successGreenBg)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
            }
        }
    }

    private var extensionQuarterOptions: [(String, String, String?)] {
        state.extensionTaxType == "VAT"
            ? [("Q1", "Q1", nil), ("Q2", "Q2", nil), ("Q3", "Q3", nil), ("Q4", "Q4", nil)]
            : [("Q1", "Q1", nil), ("Q2", "Q2", nil), ("Q3", "Q3", nil), ("Q4", "Q4", nil), ("R5", "R5", nil)]
    }

    private var extensionYears: [String] {
        let current = Calendar.current.component(.year, from: Date())
        return Array(2025...max(2026, current)).map(String.init)
    }

    private var extensionEntityOptions: [(key: String, title: String, subtitle: String)] {
        if state.extensionTaxType == "AUDIT" {
            return [
                ("CAPITAL", state.language == .arabic ? "شركات أموال\n(SAL / SARL)" : "Capital Companies\n(SAL, SARL)", state.language == .arabic ? "مهلتها القانونية ٣١ آب من العام التالي" : "Due August 31 of next year"),
                ("PARTNERSHIP", state.language == .arabic ? "شركات أشخاص" : "Partnerships", state.language == .arabic ? "مهلتها القانونية ٣٠ حزيران من العام التالي" : "Due June 30 of next year")
            ]
        }

        return [
            ("CAPITAL", state.language == .arabic ? "شركات أموال\n(SAL / SARL)" : "Capital Companies\n(SAL, SARL)", state.language == .arabic ? "مهلتها القانونية ٣١ أيار من العام التالي" : "Due May 31 of next year"),
            ("PARTNERSHIP", state.language == .arabic ? "شركات أشخاص" : "Partnerships", state.language == .arabic ? "مهلتها القانونية ٣١ آذار من العام التالي" : "Due March 31 of next year"),
            ("SOLE_REAL", state.language == .arabic ? "مؤسسة فردية\n(الربح الحقيقي)" : "Sole Proprietorship\n(Real Profit Method)", state.language == .arabic ? "مهلتها القانونية ٣١ آذار من العام التالي" : "Due March 31 of next year"),
            ("SOLE_LUMP", state.language == .arabic ? "مؤسسة فردية\n(الربح المقطوع)" : "Sole Proprietorship\n(Lump Sum Method)", state.language == .arabic ? "مهلتها القانونية ٣١ كانون الثاني من العام التالي" : "Due January 31 of next year"),
            ("EXEMPT", state.language == .arabic ? "مؤسسة مستثناة\n(الربح المقطوع)" : "Exempt Institution\n(Lump Sum Method)", state.language == .arabic ? "مهلتها القانونية ٣١ كانون الثاني من العام التالي" : "Due January 31 of next year"),
            ("EXEMPT_REAL", state.language == .arabic ? "مؤسسة مستثناة\n(الربح الحقيقي)" : "Exempt Institution\n(Real Profit Method)", state.language == .arabic ? "مهلتها القانونية ٣١ آذار من العام التالي" : "Due March 31 of next year")
        ]
    }
}

struct ContactCard: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        AppCard {
            VStack(spacing: 12) {
                Text(state.language == .arabic ? "Haddad Audit Firm — تفاصيل التواصل" : "Haddad Audit Firm — Contact Details")
                    .font(.system(size: 15, weight: .black))
                    .foregroundStyle(Color.navyPrimary)
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: .infinity)
                ContactLine(systemImage: "phone.fill", text: "+961 03 177 352")
                ContactLine(systemImage: "envelope.fill", text: "info@haddadaudit.com")
                Link(destination: URL(string: "https://www.haddadaudit.com")!) {
                    HStack(spacing: 8) {
                        Image(systemName: "globe")
                        Text("www.haddadaudit.com")
                    }
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(Color.blueAccent)
                    .frame(maxWidth: .infinity)
                    .multilineTextAlignment(.center)
                }
            }
        }
        .padding(.top, 4)
    }
}

struct ContactLine: View {
    var systemImage: String
    var text: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: systemImage)
                .foregroundStyle(Color.navyPrimary)
            Text(text)
                .foregroundStyle(Color.slateTextDark)
        }
        .font(.system(size: 13, weight: .bold))
        .frame(maxWidth: .infinity)
        .multilineTextAlignment(.center)
    }
}

struct ChildrenPicker: View {
    @EnvironmentObject private var state: AppState
    @Binding var count: Int

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(Copy.t("children", state.language))
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(Color.slateTextLight)
            Text(Copy.t("childrenMax", state.language))
                .font(.system(size: 10))
                .foregroundStyle(Color.slateTextLight.opacity(0.8))
            HStack(spacing: 4) {
                ForEach(0...5, id: \.self) { number in
                    NumberCircle(number: number, isSelected: count == number) {
                        count = number
                    }
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.top, 2)
        }
    }
}

struct TaxHighlightRow: View {
    var title: String
    var value: String
    var hasTax: Bool

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "building.columns.fill")
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(hasTax ? Color.dangerRed : Color.slateMuted)
                .padding(.top, 2)
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(hasTax ? Color.dangerRed : Color.slateTextDark)
                Text(value)
                    .font(.system(size: 18, weight: .black))
                    .foregroundStyle(hasTax ? Color.dangerRed : Color.slateTextDark)
            }
            Spacer()
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(hasTax ? Color.dangerRed.opacity(0.05) : Color.slateLight.opacity(0.6))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .stroke(hasTax ? Color.dangerRed.opacity(0.25) : Color.clear, lineWidth: 1)
        )
    }
}

struct EmployerCostBox: View {
    var result: PayrollItem
    var language: AppLanguage

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(Copy.t("employerCostBreakdown", language))
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(Color.navyMedium)
            ResultRow(title: Copy.t("grossSalary", language), value: money(result: result.grossSalary, language: language), valueColor: .navyMedium)
            ResultRow(title: Copy.t("totalNssfEmployer", language), value: money(result: result.totalNssfEmployer, language: language), valueColor: .navyMedium)
            if result.totalFamilyBenefitsAmount > 0 {
                ResultRow(title: Copy.t("lessFamilyAllowances", language), value: signedMoney(result.totalFamilyBenefitsAmount, isDeduction: true, language: language), valueColor: .dangerRed)
            }
            Divider()
            ResultRow(title: Copy.t("totalCorpCost", language), value: money(result: result.totalEmployerCost, language: language), valueColor: .successGreen, isBold: true)
        }
        .padding(12)
        .background(Color.slate50.opacity(0.7))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.slateBorder.opacity(0.8), lineWidth: 1))
    }
}

struct ComplianceBanner: View {
    var systemImage: String
    var title: String
    var text: String
    var color: Color
    var background: Color

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: systemImage)
                .font(.system(size: 22, weight: .bold))
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 12, weight: .bold))
                Text(text)
                    .font(.system(size: 11, weight: .medium))
            }
            Spacer()
        }
        .foregroundStyle(color)
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(background)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(color.opacity(0.45), lineWidth: 1))
    }
}

struct NssfBranchCard: View {
    var title: String
    var base: Double
    var ceiling: Double
    var employee: Double
    var employer: Double
    var employerRate: String
    var employeeRate: String
    var language: AppLanguage = .english

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(title)
                    .font(.system(size: 12, weight: .black))
                    .foregroundStyle(Color.navyPrimary)
                Spacer()
                Text(money(result: employee + employer, language: language))
                    .font(.system(size: 12, weight: .black))
                    .foregroundStyle((employee + employer) > 0 ? Color.blueAccent : Color.slateTextLight)
            }
            ProgressView(value: ceiling > 0 ? min(base / ceiling, 1) : 0)
                .tint((employee + employer) > 0 ? Color.blueAccent : Color.slateMuted)
            ResultRow(title: Copy.t("subjectBase", language), value: money(result: base, language: language))
            ResultRow(title: Copy.t("ceilingLimit", language), value: ceiling > 0 ? money(result: ceiling, language: language) : Copy.t("fullWageNoCeiling", language))
            ResultRow(title: "\(Copy.t("employeeContribution", language)) (\(employeeRate)):", value: money(result: employee, language: language), valueColor: employee > 0 ? .dangerRed : .slateTextLight)
            ResultRow(title: "\(Copy.t("employerContribution", language)) (\(employerRate)):", value: money(result: employer, language: language), valueColor: employer > 0 ? .blueAccent : .slateTextLight)
        }
        .padding(12)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.slateBorder, lineWidth: 1))
    }
}

struct DateFields: View {
    @EnvironmentObject private var state: AppState
    var title: String
    @Binding var day: String
    @Binding var month: String
    @Binding var year: String
    var showsTitle = true

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            if showsTitle {
                Text(title)
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(Color.slateTextLight)
            }
            HStack(spacing: 10) {
                StyledTextField(title: Copy.t("day", state.language), placeholder: "15", suffix: nil, text: Binding(get: { day }, set: { day = String(sanitizedDigits($0).prefix(2)) }))
                StyledTextField(title: Copy.t("month", state.language), placeholder: "4", suffix: nil, text: Binding(get: { month }, set: { month = String(sanitizedDigits($0).prefix(2)) }))
                StyledTextField(title: Copy.t("year", state.language), placeholder: "2026", suffix: nil, text: Binding(get: { year }, set: { year = String(sanitizedDigits($0).prefix(4)) }))
            }
        }
    }
}

struct BracketRowView: View {
    var bracket: BracketAllocation
    var total: Double
    var language: AppLanguage = .english

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(bracketTitle)
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(Color.slateTextDark)
                Spacer()
                Text(money(result: bracket.taxInBracket, language: language))
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(bracket.taxInBracket > 0 ? Color.dangerRed : Color.slateTextLight)
            }
            GeometryReader { proxy in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.slateBorder)
                    Capsule()
                        .fill(bracket.taxInBracket > 0 ? Color.blueAccent : Color.slateTextLight.opacity(0.3))
                        .frame(width: proxy.size.width * CGFloat(total > 0 ? min(bracket.amountInBracket / total, 1) : 0))
                }
            }
            .frame(height: 6)
            ResultRow(title: language == .arabic ? "المبلغ المحتسب" : "Amount charged", value: money(result: bracket.amountInBracket, language: language))
        }
        .padding(10)
        .background(Color.slateLight)
        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.slateBorder, lineWidth: 1))
    }

    private var bracketTitle: String {
        if language == .arabic {
            switch bracket.rate {
            case 0.04: return "شريحة ٤٪ (لغاية ٥٤٠ مليون)"
            case 0.07: return "شريحة ٧٪ (٥٤٠ مليون - ١.٤٤ مليار)"
            case 0.12: return "شريحة ١٢٪ (١.٤٤ مليار - ٣.٢٤ مليار)"
            case 0.16: return "شريحة ١٦٪ (٣.٢٤ مليار - ٦.٢٤ مليار)"
            case 0.21: return "شريحة ٢١٪ (٦.٢٤ مليار - ١٣.٥ مليار)"
            case 0.25: return "شريحة ٢٥٪ (فوق ١٣.٥ مليار)"
            default: return "\(Int(bracket.rate * 100))%"
            }
        }
        switch bracket.rate {
        case 0.04: "4% (0 - 540M)"
        case 0.07: "7% (540M - 1.44B)"
        case 0.12: "12% (1.44B - 3.24B)"
        case 0.16: "16% (3.24B - 6.24B)"
        case 0.21: "21% (6.24B - 13.5B)"
        case 0.25: "25% (Above 13.5B)"
        default: "\(Int(bracket.rate * 100))%"
        }
    }
}

struct WarningBox: View {
    var title: String
    var text: String

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "exclamationmark.triangle.fill")
            VStack(alignment: .leading, spacing: 3) {
                if !title.isEmpty {
                    Text(title).font(.system(size: 12, weight: .black))
                }
                Text(text).font(.system(size: 11))
            }
        }
        .foregroundStyle(Color.alertGold)
        .padding(13)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.alertGoldBg)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

struct SuccessBox: View {
    var title: String
    var text: String

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "checkmark.seal.fill")
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.system(size: 12, weight: .black))
                Text(text).font(.system(size: 11))
            }
        }
        .foregroundStyle(Color.successGreen)
        .padding(13)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.successGreenBg)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

struct TaxPulseLogo: View {
    var size: CGFloat

    var body: some View {
        Image("TaxPulseBrand")
            .resizable()
            .scaledToFill()
            .frame(width: size, height: size)
            .clipShape(RoundedRectangle(cornerRadius: size * 0.22, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: size * 0.22, style: .continuous)
                    .stroke(Color.blueAccent.opacity(0.75), lineWidth: 1.5)
            )
        .frame(width: size, height: size)
        .shadow(color: .blueAccent.opacity(0.42), radius: 24, y: 10)
        .accessibilityLabel("Tax Pulse logo")
    }
}

struct MiniEcgLine: View {
    var body: some View {
        Canvas { context, size in
            var path = Path()
            let y = size.height * 0.55
            path.move(to: CGPoint(x: 0, y: y))
            path.addLine(to: CGPoint(x: size.width * 0.24, y: y))
            path.addLine(to: CGPoint(x: size.width * 0.34, y: size.height * 0.22))
            path.addLine(to: CGPoint(x: size.width * 0.44, y: size.height * 0.82))
            path.addLine(to: CGPoint(x: size.width * 0.55, y: y))
            path.addLine(to: CGPoint(x: size.width, y: y))
            context.stroke(path, with: .color(.blueAccent), style: StrokeStyle(lineWidth: 2.2, lineCap: .round, lineJoin: .round))
        }
    }
}

struct HeartRateLine: View {
    var body: some View {
        TimelineView(.animation) { timeline in
            let phase = timeline.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 2.2) / 2.2
            Canvas { context, size in
                var path = Path()
                let centerY = size.height / 2
                for index in 0...120 {
                    let ratio = Double(index) / 120.0
                    let x = ratio * size.width
                    let y = centerY + ecgOffset(ratio: ratio, height: size.height)
                    if index == 0 {
                        path.move(to: CGPoint(x: x, y: y))
                    } else {
                        path.addLine(to: CGPoint(x: x, y: y))
                    }
                }
                context.stroke(path, with: .color(.blueAccent.opacity(0.20)), style: StrokeStyle(lineWidth: 3, lineCap: .round))
                let highlightX = size.width * phase
                context.stroke(path, with: .linearGradient(
                    Gradient(colors: [.clear, .blueAccent.opacity(0.25), .blueAccent, .blueAccent.opacity(0.25), .clear]),
                    startPoint: CGPoint(x: highlightX - 120, y: 0),
                    endPoint: CGPoint(x: highlightX + 120, y: 0)
                ), style: StrokeStyle(lineWidth: 4, lineCap: .round))
            }
        }
    }

    private func ecgOffset(ratio: Double, height: CGFloat) -> CGFloat {
        switch ratio {
        case 0.36...0.40:
            return CGFloat(-sin((ratio - 0.36) / 0.04 * .pi) * 12)
        case 0.41...0.43:
            return CGFloat(((ratio - 0.41) / 0.02) * 15)
        case 0.43...0.46:
            return CGFloat(-((ratio - 0.43) / 0.03)) * height * 0.7
        case 0.46...0.49:
            let start = -height * 0.7
            let end = height * 0.35
            return start + CGFloat((ratio - 0.46) / 0.03) * (end - start)
        case 0.49...0.51:
            return height * 0.35 - CGFloat((ratio - 0.49) / 0.02) * height * 0.35
        case 0.53...0.59:
            return CGFloat(-sin((ratio - 0.53) / 0.06 * .pi) * 18)
        default:
            return 0
        }
    }
}

func money(result amount: Double, language: AppLanguage) -> String {
    let formatter = NumberFormatter()
    formatter.numberStyle = .decimal
    formatter.maximumFractionDigits = 0
    formatter.locale = Locale(identifier: "en_US")
    let number = formatter.string(from: NSNumber(value: amount.rounded())) ?? "0"
    return language == .arabic ? "\(number) ل.ل" : "\(number) LBP"
}

func signedMoney(_ amount: Double, isDeduction: Bool, language: AppLanguage) -> String {
    if amount == 0 {
        return money(result: amount, language: language)
    }
    let sign = isDeduction ? "-" : "+"
    return "\(sign) \(money(result: amount, language: language))"
}

func formatDateParts(_ date: ExtensionDateParts, language: AppLanguage = .english) -> String {
    let enMonthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    let arMonthNames = ["كانون الثاني", "شباط", "آذار", "نيسان", "أيار", "حزيران", "تموز", "آب", "أيلول", "تشرين الأول", "تشرين الثاني", "كانون الأول"]
    let months = language == .arabic ? arMonthNames : enMonthNames
    let month = (1...12).contains(date.month) ? months[date.month - 1] : (language == .arabic ? "الشهر" : "Month")
    return language == .arabic ? "\(date.day) \(month) \(date.year)" : "\(month) \(date.day), \(date.year)"
}

struct LanguageCard: View {
    var title: String
    var subtitle: String
    var code: String
    var selected: Bool
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Text(code)
                    .font(.system(size: 16, weight: .black))
                    .foregroundStyle(Color.white)
                    .frame(width: 48, height: 48)
                    .background(selected ? Color.blueAccent : Color.white.opacity(0.10))
                    .clipShape(Circle())
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.system(size: 17, weight: .bold))
                        .foregroundStyle(Color.white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.75)
                    Text(subtitle)
                        .font(.system(size: 10.5, weight: .medium))
                        .foregroundStyle(Color.slateMuted)
                        .multilineTextAlignment(.leading)
                        .lineLimit(2)
                        .minimumScaleFactor(0.75)
                }
            }
            .padding(16)
            .frame(maxWidth: .infinity, minHeight: 88, alignment: .leading)
            .background(selected ? Color.navyMedium.opacity(0.34) : Color.white.opacity(0.05))
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(selected ? Color.blueAccent : Color.white.opacity(0.15), lineWidth: selected ? 2 : 1))
        }
        .buttonStyle(.plain)
    }
}

struct ServiceSelectionCard: View {
    @EnvironmentObject private var state: AppState
    var tab: ServiceTab
    var color: Color
    var icon: String
    var action: () -> Void

    var body: some View {
        let meta = serviceMeta(tab, language: state.language)
        Button(action: action) {
            VStack(alignment: .leading, spacing: 14) {
                Image(systemName: icon)
                    .font(.system(size: 19, weight: .bold))
                    .foregroundStyle(Color.white)
                    .frame(width: 40, height: 40)
                    .background(LinearGradient(colors: [color, color.opacity(0.72)], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                Text(meta.title)
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(Color.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
                Text(meta.description)
                    .font(.system(size: 11))
                    .foregroundStyle(Color.slateMuted)
                    .lineLimit(3)
                    .multilineTextAlignment(.leading)
            }
            .padding(16)
            .frame(maxWidth: .infinity, minHeight: 156, alignment: .leading)
            .background(Color.white.opacity(0.05))
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.12), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}

struct TopBackButton: View {
    var action: () -> Void

    var body: some View {
        HStack {
            Button(action: action) {
                Image(systemName: "chevron.left")
                    .font(.system(size: 16, weight: .black))
                    .foregroundStyle(Color.white)
                    .frame(width: 42, height: 42)
                    .background(Color.white.opacity(0.08))
                    .clipShape(Circle())
            }
            .buttonStyle(.plain)
            .padding(.leading, 16)
            .padding(.top, 16)
            Spacer()
        }
    }
}

func serviceMeta(_ tab: ServiceTab, language: AppLanguage) -> (title: String, description: String, icon: String, color: Color) {
    switch tab {
    case .payroll:
        return (Copy.t("payrollFull", language), language == .arabic ? "رواتب الموظفين والضمان الاجتماعي والشرائح الضريبية" : "Calculate payroll runs, NSSF, and tax brackets", "banknote.fill", .blueAccent)
    case .profit:
        return (Copy.t("profit", language), language == .arabic ? "ضريبة الأرباح للشركات والأفراد والشطور التصاعدية" : "Assess company net business profits and tax steps", "building.columns.fill", .successGreen)
    case .penalties:
        return (Copy.t("penalties", language), language == .arabic ? "بيان غرامات التحقق والتحصيل لمتأخرات الدفع" : "Breakdown fiscal late penalties and statutory fines", "exclamationmark.triangle.fill", .alertGold)
    case .extensions:
        return (Copy.t("extensions", language), language == .arabic ? "استعلام مهل تقديم التصاريح الممددة من المالية" : "Postponed legal filing deadlines and extensions", "calendar.badge.clock", Color(red: 0.925, green: 0.282, blue: 0.600))
    }
}
