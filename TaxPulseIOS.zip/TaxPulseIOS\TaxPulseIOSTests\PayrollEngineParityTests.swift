import XCTest
@testable import TaxPulseIOS

final class PayrollEngineParityTests: XCTestCase {
    func testAndroidReferenceMonthlyPayrollSample() {
        let result = PayrollEngine.calculate(
            basicSalary: 75_000_000,
            allowances: 0,
            bonuses: 0,
            overtime: 0,
            employmentType: .monthly,
            maritalStatus: .spouseDependent,
            childrenCount: 2,
            month: 10,
            nssfRegistered: true,
            useFamilyRebates: true,
            period: .monthly
        )

        XCTAssertEqual(result.sicknessMaternityEmployee, 2_250_000, accuracy: 0.001)
        XCTAssertEqual(result.taxableSalary, 11_250_000, accuracy: 0.001)
        XCTAssertEqual(result.taxAmount, 230_000, accuracy: 0.001)
    }

    func testAnnualBracketSixStartsAtSevenPointTwoBillion() {
        let bracket = PayrollEngine.annualBrackets()[5]

        XCTAssertEqual(bracket.minAmount, 7_200_000_000, accuracy: 0.001)
        XCTAssertEqual(bracket.maxAmount, 13_500_000_000, accuracy: 0.001)
        XCTAssertEqual(bracket.rate, 0.20, accuracy: 0.000_001)
    }

    func testDailyAndLumpSumBranchesMatchAndroidFlags() {
        let daily = PayrollEngine.calculate(
            basicSalary: 2_000_000,
            allowances: 500_000,
            employmentType: .daily,
            maritalStatus: .single,
            childrenCount: 0,
            month: 10,
            nssfRegistered: false,
            useFamilyRebates: true,
            period: .monthly
        )

        let lump = PayrollEngine.calculate(
            basicSalary: 50_000_000,
            employmentType: .lumpSumWages,
            maritalStatus: .single,
            childrenCount: 2,
            month: 10,
            nssfRegistered: false,
            useFamilyRebates: true,
            period: .monthly
        )

        XCTAssertTrue(daily.isDailyTaxApplied)
        XCTAssertEqual(daily.familyRebatesAmount, 1_500_000, accuracy: 0.001)
        XCTAssertTrue(lump.isLumpSumApplied)
        XCTAssertEqual(lump.taxAmount, 1_500_000, accuracy: 0.001)
    }
}
